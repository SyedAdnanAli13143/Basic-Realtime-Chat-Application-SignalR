import { Component, OnInit, OnDestroy } from '@angular/core';
import { SignalrService } from './signalr.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit, OnDestroy {

  constructor(private signalrService: SignalrService) {}

  ngOnInit() {
    this.signalrService.startConnection();

    // You may need to handle this differently based on your app logic
    setTimeout(() => {
      if (this.signalrService['isConnected']) { // Accessing private property for simplicity
        this.signalrService.askServerListener();
        this.signalrService.askServer();
      } else {
        console.error('SignalR connection is not established yet.');
      }
    }, 2000); // Adjust timeout as necessary or use more reliable connection state handling
  }

  ngOnDestroy() {
    this.signalrService.hubConnection.off("askServerResponse");
  }
}
