import { Injectable } from '@angular/core';
import * as signalR from '@microsoft/signalr'; // Use the latest package

@Injectable({ providedIn: 'root' })
export class SignalrService {
     hubConnection!: signalR.HubConnection;
    private isConnected = false;

    constructor() { }

    startConnection = () => {
        this.hubConnection = new signalR.HubConnectionBuilder()
            .withUrl('http://localhost:5081/toastr', {
                skipNegotiation: true,
                transport: signalR.HttpTransportType.WebSockets
            })
            .build();

        this.hubConnection
            .start()
            .then(() => {
                console.log('Hub Connection Started!');
                this.isConnected = true;
            })
            .catch((err: any) => {
                console.error('Error while starting connection: ' + err);
                this.isConnected = false;
            });
    }

    askServer() {
        if (this.isConnected) {
            this.hubConnection.invoke("askServer", "hey")
                .catch((err: any) => console.error('Error invoking askServer: ' + err));
        } else {
            console.error('Cannot send data. Connection is not established.');
        }
    }

    askServerListener() {
        if (this.isConnected) {
            this.hubConnection.on("askServerResponse", (response: string) => {
                console.log(response);
            });
        } else {
            console.error('Cannot listen for server responses. Connection is not established.');
        }
    }
}
